


var dest = new Date("August 7, 2020 10:00:00").getTime();

var x = setInterval(function(){
var now = new Date().getTime();

var diff = dest - now;

var days = Math.floor(diff / (1000 * 60 * 60 * 24));
var hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

var minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

var seconds = Math.floor((diff % (1000 * 60)) / 1000);


document.getElementById("dday").innerHTML = days;
document.getElementById("dhour").innerHTML = hours;
document.getElementById("dmin").innerHTML = minutes;
document.getElementById("dsec").innerHTML = seconds;

}, 1000);